/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simplechat;
import java.sql.*;
import java.util.ArrayList;

// make database
public class Database{
    // all needs for the connection
    private Connection conn;
    private Statement s;
    private ResultSet rs;
    private final String url = "jdbc:mysql://localhost/chat";
    private final String username = "root";
    private final String password = "";
    private String query;
    
    
    // to connect to database
    public void connectDB(){
        try{
            
            conn = DriverManager.getConnection(url,  username , password);
            s = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
        }catch(SQLException  e){
            System.out.println(e.getMessage());
        }
    }
    
    // from here is the method for the program
    // print item 
    public ArrayList printItem(){
        ArrayList<String> values = new ArrayList<>();
        try{
            query = "select * from packages";
            
            rs = s.executeQuery(query);
            while (rs.next()){
                values.add(rs.getString("packages_id") + ". " + rs.getString("name") + " " + rs.getString("price"));
            }
        }catch(SQLException e){
            values.add(e.getMessage());
        }
        
        return values;
    }
    
    // to insert the order into table 'orders'
    public void addOrder(String name, String id){
        try{
            query = "INSERT INTO `orders` (`username`, `packages_id`) VALUES ('" + name + "', '" + id + "');";
            s.executeUpdate(query);
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }
}

