package simplechat;

import java.io.*;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;

// use constructor
class Client {
    
    // setting up to connect the server
    
    // server and port like an adress
    String serverName = "127.0.0.1";
    int port = 3000;
    
    // BufferedReader for something like scanner
    BufferedReader read = new BufferedReader(new InputStreamReader(System.in));
    
    // socket for recieve and send 'something' point
    Socket client;
    
    // to send message
    OutputStream outToServer;
    DataOutputStream out ;
    
  public void sendMessage(String message){
        try {
            // Socket
            client = new Socket( serverName, port );
	
            // OutputStream
            outToServer = client.getOutputStream();
		
            // DataOutputStream
            out = new DataOutputStream( outToServer );
            
            //sending the msg
            out.writeUTF(message);
        } catch (IOException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
  }
}