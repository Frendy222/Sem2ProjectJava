package testchat;

import java.io.*;
import java.net.*;
import java.util.ArrayList;

class Server{
  public Server() {
    int port = 3000;
    String message ;
    
    try {
      // ServerSocket
      ServerSocket servSocket = new ServerSocket(port);
      System.out.println("Server served on port 3000");
      
      while(true) {
		// Socket
		Socket server = servSocket.accept();
		
		// DataInputStream
		DataInputStream in = new DataInputStream( server.getInputStream() );
		message = in.readUTF();
		System.out.println( message );
      }
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

}